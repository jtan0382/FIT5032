﻿//using System.ComponentModel.DataAnnotations;

//namespace MHealth.Models.Domain.View
//{
//    public class MRIPostViewModel
//    {
//        public string UserId { get; set; }
//        public string StaffId { get; set; }
//        public string BookingId { get; set; }
//        [Required]
//        public string Description { get; set; }
//        //[Required]
//        [Required(ErrorMessage = "Please select a file.")]
//        [DataType(DataType.Upload)]
//        //[FileSize(5 * 1024 * 1024, ErrorMessage = "File size should not exceed 5MB.")]
//        //[AllowedExtensions(new string[] { ".jpg", ".jpeg", ".png", ".gif" }, ErrorMessage = "Invalid file format.")]
//        public IFormFile File { get; set; }
//    }
//}


